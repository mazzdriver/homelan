export const PROTOCOL = 'homelan.rpc';
export const PROTOCOL_VERSION = 1;
export const CLIENT_VERSION = '2.1.0';
export const OPERATIONS = Object.freeze([
  'ping','inspect','plan','status','diagnose','lock','locknow','newpass','autologin',
  'locker.set','arm.set','poweroff','install','update'
]);
export const ERROR = Object.freeze({
  INVALID_REQUEST:'INVALID_REQUEST', UNSUPPORTED_VERSION:'UNSUPPORTED_VERSION',
  UNKNOWN_OPERATION:'UNKNOWN_OPERATION', PERMISSION_DENIED:'PERMISSION_DENIED',
  NOT_SUPPORTED:'NOT_SUPPORTED', PRECONDITION_FAILED:'PRECONDITION_FAILED',
  OPERATION_FAILED:'OPERATION_FAILED', PARTIAL_FAILURE:'PARTIAL_FAILURE'
});
export function request(operation, params = {}, id = cryptoRandomId()) {
  if (!OPERATIONS.includes(operation)) throw new TypeError(`Unsupported operation: ${operation}`);
  return { protocol: PROTOCOL, version: PROTOCOL_VERSION, id, operation, params };
}
export function success(req, result = {}) {
  return { protocol:PROTOCOL, version:PROTOCOL_VERSION, id:req.id, ok:true, result };
}
export function failure(req, code, message, details = undefined) {
  return { protocol:PROTOCOL, version:PROTOCOL_VERSION, id:req?.id ?? null, ok:false,
    error:{code,message,...(details===undefined?{}:{details})} };
}
export function validateRequest(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return 'Request must be an object';
  if (value.protocol !== PROTOCOL) return 'Unknown protocol';
  if (value.version !== PROTOCOL_VERSION) return 'Unsupported protocol version';
  if (typeof value.id !== 'string' || !value.id || value.id.length > 128) return 'Invalid request id';
  if (!OPERATIONS.includes(value.operation)) return 'Unknown operation';
  if (!value.params || typeof value.params !== 'object' || Array.isArray(value.params)) return 'params must be an object';
  return null;
}
function cryptoRandomId(){ return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,12)}`; }
